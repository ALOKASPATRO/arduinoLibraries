#ifndef myLIB_h
#define myLIB_h

#include "Arduino.h"


class control{
  public:
    control(int pin, int delay);
    void ON();
    void OFF();
    int _pin;
    int _delay;};
    
#endif
