#include "myLIB.h"


control::control(int pin, int delay){
  pinMode(pin,OUTPUT);
  _pin = pin;
  _delay = delay;}

void control::ON(){
  digitalWrite(_pin,HIGH);
  delay(_delay);}

void control::OFF(){
  digitalWrite(_pin,LOW);
  delay(_delay);}
